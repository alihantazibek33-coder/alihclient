package dev.shadowclient.module;
public enum ActivationMode {
    TOGGLE("Toggle"), HOLD_KEY("Hold key"), AUTO("Auto");
    private final String title;
    ActivationMode(String title) { this.title = title; }
    public String title() { return title; }
    public ActivationMode next() {
        ActivationMode[] all = values();
        return all[(ordinal() + 1) % all.length];
    }
}
