package dev.shadowclient.module;
import java.util.ArrayList;
import java.util.List;
public final class ModuleManager {
    private static final List<ClientModule> MODULES = new ArrayList<>();
    private ModuleManager(){}
    public static void init() {
        if(!MODULES.isEmpty()) return;
        add("AimAssist","Aim adjustment settings",ModuleCategory.COMBAT,"Target in view");
        add("KillAura","Combat targeting settings",ModuleCategory.COMBAT,"Weapon in hotbar");
        add("ESP","Entity highlighting settings",ModuleCategory.VISUALS,"None");
        add("AutoCrystal","Crystal PvP workflow settings",ModuleCategory.COMBAT,"Obsidian + End Crystal");
        add("AutoAnchor","Respawn Anchor PvP workflow settings",ModuleCategory.COMBAT,"Anchor + Glowstone");
        add("AutoMaceCombo","Mace combo and shield-response settings",ModuleCategory.COMBAT,"Mace + axe");
        add("AutoMace","Mace attack settings",ModuleCategory.COMBAT,"Mace");
        add("AutoShieldBreak","Axe shield-break settings",ModuleCategory.COMBAT,"Axe");
        add("TriggerBot","Attack-on-target settings",ModuleCategory.COMBAT,"Weapon in hotbar");
    }
    private static void add(String n,String d,ModuleCategory c,String r){MODULES.add(new ClientModule(n,d,c,r));}
    public static List<ClientModule> inCategory(ModuleCategory c){return MODULES.stream().filter(m->m.category()==c).toList();}
}
