package dev.shadowclient.module;
public enum ModuleCategory {
    COMBAT("Combat"), VISUALS("Visuals");
    private final String title;
    ModuleCategory(String title) { this.title = title; }
    public String title() { return title; }
}
