package dev.shadowclient.gui;

import dev.shadowclient.module.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.List;

public final class ClickGuiScreen extends Screen {
    private ModuleCategory selected=ModuleCategory.COMBAT;
    private int px,py,pw,ph,listX,listY,listW;
    private static final int ACCENT=0xFFB18CFF;
    public ClickGuiScreen(){super(Text.literal("ShadowClient Combat"));}

    @Override public void render(DrawContext ctx,int mx,int my,float delta){
        renderBackground(ctx,mx,my,delta);
        pw=Math.min(690,width-24); ph=Math.min(410,height-24);
        px=(width-pw)/2; py=(height-ph)/2; int sidebar=150;
        ctx.fill(px,py,px+pw,py+ph,0xF0101118);
        ctx.fill(px,py,px+pw,py+3,ACCENT);
        ctx.fill(px,py+48,px+pw,py+49,0xFF30313D);
        ctx.drawText(textRenderer,"SHADOWCLIENT",px+16,py+13,0xFFF4F0FF,false);
        ctx.drawText(textRenderer,"COMBAT BUILD / 1.21.4",px+128,py+14,ACCENT,false);
        ctx.drawText(textRenderer,"RIGHT SHIFT",px+pw-88,py+15,0xFF9293A5,false);
        int cy=py+62;
        for(ModuleCategory cat:ModuleCategory.values()){
            boolean active=cat==selected;
            ctx.fill(px+12,cy,px+sidebar-8,cy+32,active?0xFF30283F:0xFF171820);
            if(active)ctx.fill(px+12,cy,px+15,cy+32,ACCENT);
            ctx.drawText(textRenderer,cat.title(),px+25,cy+11,active?0xFFFFFFFF:0xFFB5B6C5,false);
            cy+=38;
        }
        listX=px+sidebar+8; listY=py+60; listW=pw-sidebar-24;
        ctx.drawText(textRenderer,selected.title().toUpperCase(),listX,py+14,0xFFE6E1F0,false);
        ctx.drawText(textRenderer,"Left click: toggle | Right click: activation mode",listX,py+32,0xFF8E8FA0,false);
        List<ClientModule> mods=ModuleManager.inCategory(selected);
        int ry=listY,rowH=48,visible=Math.max(0,(py+ph-28-listY)/rowH);
        for(int i=0;i<Math.min(mods.size(),visible);i++){
            ClientModule m=mods.get(i); boolean hover=mx>=listX&&mx<=listX+listW&&my>=ry&&my<=ry+41;
            ctx.fill(listX,ry,listX+listW,ry+41,hover?0xFF292A36:0xFF1C1D26);
            ctx.drawText(textRenderer,m.name(),listX+10,ry+5,0xFFEDECF5,false);
            ctx.drawText(textRenderer,m.description(),listX+10,ry+18,0xFF999AAA,false);
            ctx.drawText(textRenderer,"Needs: "+m.requirement(),listX+10,ry+30,0xFF77798B,false);
            int mx0=listX+listW-118;
            ctx.fill(mx0,ry+7,mx0+108,ry+24,0xFF282431);
            ctx.drawText(textRenderer,m.mode().title(),mx0+7,ry+12,ACCENT,false);
            ctx.fill(listX+listW-44,ry+27,listX+listW-8,ry+37,m.enabled()?0xFF4A3A64:0xFF30313D);
            ctx.drawText(textRenderer,m.enabled()?"ON":"OFF",listX+listW-39,ry+28,m.enabled()?ACCENT:0xFF9A9BA8,false);
            ry+=rowH;
        }
        ctx.fill(px+12,py+ph-22,px+pw-12,py+ph-21,0xFF292A35);
        ctx.drawText(textRenderer,"Module menu framework; gameplay logic still needs implementation.",px+16,py+ph-15,0xFF777888,false);
        super.render(ctx,mx,my,delta);
    }

    @Override public boolean mouseClicked(double mx,double my,int button){
        int cy=py+62;
        for(ModuleCategory cat:ModuleCategory.values()){
            if(mx>=px+12&&mx<=px+142&&my>=cy&&my<=cy+32){selected=cat;return true;}
            cy+=38;
        }
        List<ClientModule> mods=ModuleManager.inCategory(selected);
        int ry=listY,rowH=48,visible=Math.max(0,(py+ph-28-listY)/rowH);
        for(int i=0;i<Math.min(mods.size(),visible);i++){
            if(mx>=listX&&mx<=listX+listW&&my>=ry&&my<=ry+41){
                if(button==0)mods.get(i).toggle();
                else if(button==1)mods.get(i).nextMode();
                else return super.mouseClicked(mx,my,button);
                return true;
            }
            ry+=rowH;
        }
        return super.mouseClicked(mx,my,button);
    }
    @Override public boolean shouldPause(){return false;}
}
