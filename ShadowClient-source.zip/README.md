# ShadowClient Combat — Minecraft Java 1.21.4 Fabric

The previous HUD/quality-of-life module list has been removed. This source now lists:
- AimAssist
- KillAura
- ESP
- AutoCrystal
- AutoAnchor
- AutoMaceCombo
- AutoMace
- AutoShieldBreak
- TriggerBot

GUI: Right Shift opens/closes; left-click toggles a module; right-click cycles activation mode (Toggle -> Hold key -> Auto). The menu shows basic hotbar item requirements.

Important: this is a UI/module framework only. Module toggles, categories and mode selection are implemented, but actual combat automation, inventory swapping, crystal/anchor placement and ESP rendering are not yet implemented. Build with JDK 21 and Gradle using `gradle build`; output should be in `build/libs/`.
