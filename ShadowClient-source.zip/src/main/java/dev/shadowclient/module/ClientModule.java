package dev.shadowclient.module;
public final class ClientModule {
    private final String name, description, requirement;
    private final ModuleCategory category;
    private boolean enabled;
    private ActivationMode mode = ActivationMode.TOGGLE;
    public ClientModule(String name, String description, ModuleCategory category, String requirement) {
        this.name=name; this.description=description; this.category=category; this.requirement=requirement;
    }
    public String name(){return name;}
    public String description(){return description;}
    public String requirement(){return requirement;}
    public ModuleCategory category(){return category;}
    public boolean enabled(){return enabled;}
    public ActivationMode mode(){return mode;}
    public void toggle(){enabled=!enabled;}
    public void nextMode(){mode=mode.next();}
}
