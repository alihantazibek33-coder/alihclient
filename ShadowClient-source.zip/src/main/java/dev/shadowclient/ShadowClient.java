package dev.shadowclient;

import dev.shadowclient.gui.ClickGuiScreen;
import dev.shadowclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class ShadowClient implements ClientModInitializer {
    private static KeyBinding guiKey;
    private static boolean previousRightShift;

    @Override public void onInitializeClient() {
        ModuleManager.init();
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.shadowclient.open_gui", InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT, "category.shadowclient"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean down = InputUtil.isKeyPressed(client.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean edge = down && !previousRightShift;
            previousRightShift = down;
            boolean queued = false;
            while (guiKey.wasPressed()) queued = true;
            if ((edge || queued) && client.player != null) {
                if (client.currentScreen instanceof ClickGuiScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
        });
    }
}
